### API
- [x] `/create-room` -> create a room with a random password
- [x] `/destroy-room` -> shut down a room

### Socket (Server)
- [x] join to room id onConnection, if could't drop the user
- [x] `destroyed` 
- [x] `configure` 
- [x] `disconnect`
